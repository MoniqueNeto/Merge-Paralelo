from threading import Thread
import numpy as np
from time import *
from concurrent.futures import ThreadPoolExecutor


size = 2000000

def rand_nums(start, end, num=10):
    res = []
    for j in range(num):
        res.append(np.random.randint(start, end))
    return res


original_list = list(range(0, size))
            
start = len( original_list) - 1
reversed_list = [original_list[i] for i in range (start, -1, -1)]


shared_result = 0
shared_result_l = 0



def mergeSort(arr):
    if len(arr) > 1:
        mid = len(arr)//2
        L = arr[:mid]
        R = arr[mid:]
        
        
        if len(arr) >= 1000000:
            t_L = Thread(target=mergeSort, args=[[L]])
            t_R = Thread(target=mergeSort, args=[[R]])
            t_L.start(); t_R.start()
            t_L.join(); t_R.join()
        else:
            mergeSort(L)
            mergeSort(R)
        
        
        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] <= R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1
        
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1
        
        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1
            
def wrapper(func, v, exec):
    start = time_ns()
    print("Começou...")   
    func(v, exec)
    end = time_ns()
    period = end - start
    print("tempo (ns)", period)     


if __name__ == '__main__':
    vector_local = np.array(original_list)
    vector_copy = vector_local.view()
    with ThreadPoolExecutor() as executor:
        wrapper(mergeSort_t, vector_local, executor)
        print(vector_local)
        wrapper(mergeSort, vector_copy, executor)
        print(vector_copy)
        executor.shutdown()